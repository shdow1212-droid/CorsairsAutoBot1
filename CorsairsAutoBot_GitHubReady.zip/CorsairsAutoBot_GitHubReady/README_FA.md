# Corsairs Auto Bot — Android 16

این پروژه برای ساخت یک APK آزمایشی روی خود گوشی آماده شده است.

## نکته مهم
این برنامه از Accessibility برای گرفتن screenshot و ارسال tap استفاده می‌کند.
Android مستند کرده که AccessibilityService می‌تواند `takeScreenshot()` و
`dispatchGesture()` را در صورت اعلام capability مربوطه استفاده کند.

## سازگاری
- compileSdk: 36
- targetSdk: 36
- minSdk: 30
- Kotlin
- Java/Kotlin toolchain: JDK 17
- بدون OpenCV و بدون NDK

## ساخت روی گوشی
1. پروژه را در یک IDE اندرویدی که Gradle/AGP 8.6.1 و JDK 17 را پشتیبانی می‌کند باز کنید.
2. Gradle Sync را انجام دهید.
3. `assembleDebug` را اجرا کنید.
4. APK خروجی debug را نصب کنید.
5. Settings > Accessibility > Corsairs Auto Bot را روشن کنید.
6. بازی را اجرا کنید.

## تنظیمات تشخیص
اگر محل مرکز بازی یا دکمه در گوشی شما متفاوت بود، این مقادیر در
`CorsairsAccessibilityService.kt` قابل تغییرند:
- `cx = w * 0.50f`
- `cy = h * 0.415f`
- `x = width * 0.50f`
- `y = height * 0.835f`

این نسخه یک prototype است؛ تشخیص تصویری برای نسخه‌های بعدی می‌تواند با
داده‌های بیشتر از ویدیوی واقعی بازی دقیق‌تر شود.
